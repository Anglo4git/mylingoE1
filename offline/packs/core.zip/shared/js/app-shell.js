/* Mylingo App Shell — shared bottom navigation component (Agent 87)
 *
 * Single injectable bottom nav: Home / Courses / Progress.
 * Navigation derives the deployment root from this shared script URL, so it
 * works both at the domain root and under a GitHub Pages/project sub-path.
 *
 * Usage: include this file (and shared/css/app-shell.css) on any page.
 * It self-mounts on DOMContentLoaded and exposes window.MylingoAppShell:
 *   - mount(): idempotent, called automatically
 *   - setVisible(bool): show/hide the bar (used by shared/quiz.html to
 *     hide the nav during an active question and show it on
 *     start/end/error/loading overlays)
 *   - activeKey(): which tab is considered "active" for the current page
 *
 * Does not wire itself into any page's layout beyond appending itself to
 * <body> and adding a body class that reserves bottom padding — no other
 * page markup is required.
 */
(function(){
  'use strict';
  if(window.MylingoAppShell) return;

  // Resolve the deployment root from the shared script URL instead of assuming
  // every page is exactly one directory below root. This also keeps navigation
  // correct when the app is deployed under a GitHub Pages sub-path.
  var script=document.currentScript;
  var scriptPath='';
  try{scriptPath=script&&script.src?new URL(script.src,location.href).pathname:'';}catch(e){}
  var ROOT=scriptPath.replace(/\/shared\/js\/app-shell\.js$/,'/');
  if(!ROOT||ROOT===scriptPath) ROOT='/';
  if(ROOT.length>1&&!ROOT.endsWith('/')) ROOT+='/';

  var ICONS={
    home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5a1 1 0 0 0 1 1H9.5v-6h5v6H17.5a1 1 0 0 0 1-1V10"/></svg>',
    courses:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
    progress:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v18h18"/><path d="M7 15v3"/><path d="M12 10v8"/><path d="M17 6v12"/></svg>'
  };

  var TABS=[
    {key:'home',     label:'Home',     href:ROOT+'main/index.html'},
    {key:'courses',  label:'Courses',  href:ROOT+'courses/index.html'},
    {key:'progress', label:'Progress', href:ROOT+'main/progress.html'}
  ];
  // Route-matching regexes. Order matters — first match wins.
  var ROUTES=[
    {key:'progress', re:/\/main\/progress\.html(?:$|[?#])/},
    {key:'progress', re:/\/(a1|a2|b1|b2|c1|c2)\/dashboard\.html(?:$|[?#])/},
    {key:'courses',  re:/\/courses\//},
    {key:'home',     re:/\/main\/index\.html(?:$|[?#])/},
    {key:'home',     re:/\/site\/?(?:$|[?#])/},
    {key:'home',     re:/\/(?:$|[?#])/}
  ];

  function activeKey(){
    var path=(location.pathname||'').replace(/\\/g,'/');
    var rootPath=ROOT.length>1?ROOT.slice(0,-1):'';
    if(rootPath&&(path===rootPath||path===rootPath+'/')) return 'home';
    for(var i=0;i<ROUTES.length;i++){
      if(ROUTES[i].re.test(path)) return ROUTES[i].key;
    }
    return null;
  }

  function build(){
    var active=activeKey();
    var nav=document.createElement('nav');
    nav.id='mylingoAppShell';
    nav.className='mylingo-appshell';
    nav.setAttribute('role','navigation');
    nav.setAttribute('aria-label','Primary');
    nav.setAttribute('data-hidden','false');
    nav.innerHTML=TABS.map(function(t){
      var isActive=t.key===active;
      return '<a class="as-tab'+(isActive?' active':'')+'" href="'+t.href+'"'+(isActive?' aria-current="page"':'')+'>'+
        '<span class="as-icon">'+ICONS[t.key]+'</span>'+
        '<span class="as-label">'+t.label+'</span>'+
      '</a>';
    }).join('');
    return nav;
  }

  function mount(){
    if(document.getElementById('mylingoAppShell')) return;
    if(!document.body) return;
    var nav=build();
    document.body.appendChild(nav);
    document.body.classList.add('has-mylingo-appshell');
    bindPressAnimation(nav);
  }

  // Subtle iOS-style press feedback: the icon/label scale down instantly on
  // touch/press, then spring back on release. Uses pointer events (not the
  // CSS :active pseudo-class) so it fires reliably on iOS Safari, which
  // otherwise suppresses :active on plain link taps. Each page is a full
  // reload on navigation, so this only needs to cover the moment of the tap
  // itself — the spring-back class is a no-op if the page unloads first.
  function bindPressAnimation(nav){
    var current=null;
    function press(tab){
      if(current&&current!==tab) release(current);
      tab.classList.remove('as-release');
      tab.classList.add('as-press');
      current=tab;
    }
    function release(tab){
      tab.classList.remove('as-press');
      tab.classList.add('as-release');
      window.setTimeout(function(){tab.classList.remove('as-release')},400);
      if(current===tab) current=null;
    }
    nav.addEventListener('pointerdown',function(e){
      var tab=e.target.closest('.as-tab');
      if(tab) press(tab);
    });
    ['pointerup','pointercancel','pointerleave'].forEach(function(type){
      nav.addEventListener(type,function(e){
        var tab=e.target.closest('.as-tab')||current;
        if(tab) release(tab);
      });
    });
  }

  function setVisible(visible){
    var el=document.getElementById('mylingoAppShell');
    if(!el) return;
    el.setAttribute('data-hidden',visible?'false':'true');
    el.setAttribute('aria-hidden', visible ? 'false' : 'true');
    if (visible) el.removeAttribute('inert'); else el.setAttribute('inert','');
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',mount);
  }else{
    mount();
  }

  window.MylingoAppShell={mount:mount,setVisible:setVisible,activeKey:activeKey};
})();
